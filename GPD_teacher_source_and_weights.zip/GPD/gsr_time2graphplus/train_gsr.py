import argparse
import json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm

from gsr_t2g.config import GSRTime2GraphConfig
from gsr_t2g.data import (
    build_fold_subject_ids,
    build_segment_table,
    collect_subject_ids_from_split,
    load_subject_samples,
    records_to_arrays,
    split_train_val_subjects,
)
from gsr_t2g.metrics import segment_metrics, subject_topk_metrics
from gsr_t2g.model import Time2GraphPlusForGSR
from gsr_t2g.utils import ensure_dir, set_seed, to_device


def _build_split_arrays(
    sample_map: Dict[str, object], sids: List[str]
) -> Tuple[np.ndarray, np.ndarray, Dict[str, object], np.ndarray, np.ndarray]:
    samples = [sample_map[sid] for sid in sids if sid in sample_map]
    if len(samples) == 0:
        return (
            np.zeros((0, 0, 1), dtype=np.float32),
            np.zeros((0,), dtype=np.int64),
            {
                "subject_id": [],
                "seg_idx": np.zeros((0,), dtype=np.int64),
                "question_digit": np.zeros((0,), dtype=np.int64),
                "chosen_digit": np.zeros((0,), dtype=np.int64),
            },
            np.zeros((0, 5), dtype=np.float32),
            np.zeros((0, 3), dtype=np.float32),
        )
    records, X_raw, P_raw, H_raw = build_segment_table(samples)
    return records_to_arrays(records, X_raw, P_raw, H_raw)


def _run_eval(
    model: Time2GraphPlusForGSR,
    feats: np.ndarray,
    adjs: np.ndarray,
    p5: np.ndarray,
    h3: np.ndarray,
    y: np.ndarray,
    batch_size: int,
    device: torch.device,
) -> Tuple[np.ndarray, np.ndarray]:
    ds = TensorDataset(
        torch.from_numpy(feats.astype(np.float32)),
        torch.from_numpy(adjs.astype(np.float32)),
        torch.from_numpy(p5.astype(np.float32)),
        torch.from_numpy(h3.astype(np.float32)),
        torch.from_numpy(y.astype(np.int64)),
    )
    ld = DataLoader(ds, batch_size=int(batch_size), shuffle=False)
    model.eval()
    ys: List[np.ndarray] = []
    ps: List[np.ndarray] = []
    with torch.no_grad():
        for feat, adj, pp, hh, yy in ld:
            feat = feat.to(device).float()
            adj = adj.to(device).float()
            pp = pp.to(device).float()
            hh = hh.to(device).float()
            logits = model(feat, adj, pp, hh)
            ppos = torch.softmax(logits, dim=1)[:, 1]
            ys.append(yy.numpy())
            ps.append(ppos.detach().cpu().numpy())
    if len(ys) == 0:
        return np.zeros((0,), dtype=np.int64), np.zeros((0,), dtype=np.float32)
    return np.concatenate(ys, axis=0), np.concatenate(ps, axis=0)


def _save_segment_predictions(path: Path, fold: int, meta: Dict[str, object], y_true: np.ndarray, score_pos: np.ndarray) -> None:
    import csv

    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["fold", "subject_id", "seg_idx", "question_digit", "chosen_digit", "y_true", "score_pos"])
        subject_ids = meta["subject_id"]
        seg_idx = np.asarray(meta["seg_idx"], dtype=np.int64)
        qd = np.asarray(meta["question_digit"], dtype=np.int64)
        cd = np.asarray(meta["chosen_digit"], dtype=np.int64)
        for i in range(len(subject_ids)):
            w.writerow(
                [
                    int(fold),
                    str(subject_ids[i]),
                    int(seg_idx[i]),
                    int(qd[i]),
                    int(cd[i]),
                    int(y_true[i]),
                    float(score_pos[i]),
                ]
            )


def main() -> None:
    ap = argparse.ArgumentParser(description="Time2GraphPlus-style 5-fold training for GSR number-guess task")
    ap.add_argument("--data_root", type=str, default="./data")
    ap.add_argument("--split_root", type=str, default="./data_split/5fold")
    ap.add_argument("--out_dir", type=str, default="./results/time2graphplus_gsr_cv5")
    ap.add_argument("--folds", type=int, default=5)

    ap.add_argument("--source_fs", type=float, default=256.0)
    ap.add_argument("--target_fs", type=float, default=32.0)
    ap.add_argument("--lowpass_hz", type=float, default=2.0)
    ap.add_argument("--event_sec", type=float, default=14.0)
    ap.add_argument("--norm_mode", type=str, default="subject", choices=["subject", "clip"])

    ap.add_argument("--num_segment", type=int, default=14)
    ap.add_argument("--seg_length", type=int, default=32)
    ap.add_argument("--K", type=int, default=48)
    ap.add_argument("--percentile", type=float, default=85.0)

    ap.add_argument("--epochs", type=int, default=40)
    ap.add_argument("--batch_size", type=int, default=64)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight_decay", type=float, default=5e-4)
    ap.add_argument("--pos_weight", type=float, default=5.0)
    ap.add_argument("--device", type=str, default="cuda")
    ap.add_argument("--seed", type=int, default=42)

    ap.add_argument("--select_on", type=str, default="test", choices=["test", "val"])
    ap.add_argument("--val_ratio", type=float, default=0.1)
    ap.add_argument("--select_metric", type=str, default="top1", choices=["top1", "f1"])
    ap.add_argument("--agg_mode", type=str, default="mean", choices=["sum", "mean", "logsumexp", "max"])

    ap.add_argument("--use_cache", type=int, default=1)
    ap.add_argument("--cache_dir", type=str, default="")
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--use_personality", type=int, default=1, choices=[0, 1])
    ap.add_argument("--personality_scale", type=float, default=0.2)
    ap.add_argument("--personality_hidden", type=int, default=16)
    ap.add_argument("--personality_fusion", type=str, default="interaction", choices=["interaction", "concat"])
    ap.add_argument("--use_handcrafted", type=int, default=0, choices=[0, 1], help="use rule-3 features (amp/auc/slope)")
    ap.add_argument("--handcrafted_scale", type=float, default=1.0)
    ap.add_argument("--handcrafted_hidden", type=int, default=16)
    ap.add_argument("--handcrafted_fusion", type=str, default="interaction", choices=["interaction", "concat"])
    args = ap.parse_args()

    cfg = GSRTime2GraphConfig(
        source_fs=args.source_fs,
        target_fs=args.target_fs,
        lowpass_hz=args.lowpass_hz,
        event_sec=args.event_sec,
        norm_mode=args.norm_mode,
        num_segment=args.num_segment,
        seg_length=args.seg_length,
        K=args.K,
        percentile=args.percentile,
        epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        weight_decay=args.weight_decay,
        pos_weight=args.pos_weight,
        device=args.device,
        seed=args.seed,
        use_personality=args.use_personality,
        personality_scale=args.personality_scale,
        personality_hidden=args.personality_hidden,
        personality_fusion=args.personality_fusion,
        use_handcrafted=args.use_handcrafted,
        handcrafted_scale=args.handcrafted_scale,
        handcrafted_hidden=args.handcrafted_hidden,
        handcrafted_fusion=args.handcrafted_fusion,
    )
    set_seed(cfg.seed)
    device = to_device(cfg.device)

    expected_len = int(round(float(cfg.target_fs) * float(cfg.event_sec)))
    if expected_len != int(cfg.num_segment * cfg.seg_length):
        raise ValueError(
            f"length mismatch: target_fs*event_sec={expected_len}, "
            f"but num_segment*seg_length={cfg.num_segment * cfg.seg_length}"
        )

    out_dir = Path(args.out_dir)
    ensure_dir(str(out_dir))
    cache_dir = None
    if int(args.use_cache) == 1:
        cache_dir = str(Path(args.cache_dir)) if str(args.cache_dir).strip() else str(out_dir / "cache_subject")
        ensure_dir(cache_dir)

    all_ids = collect_subject_ids_from_split(args.split_root, folds=args.folds)
    sample_map = load_subject_samples(
        data_root=args.data_root,
        subject_ids=all_ids,
        cfg=cfg,
        cache_dir=cache_dir,
        num_workers=args.num_workers,
    )
    print(f"loaded subjects: {len(sample_map)}/{len(all_ids)}")
    print(
        f"fixed event length: {cfg.event_sec:.1f}s -> {expected_len} samples @ {cfg.target_fs:g}Hz; "
        f"agg_mode={args.agg_mode}; "
        f"norm_mode={cfg.norm_mode}; "
        f"personality={'big5_interaction' if int(cfg.use_personality)==1 else 'off'}; "
        f"handcrafted={('amp_auc_slope_' + str(cfg.handcrafted_fusion)) if int(cfg.use_handcrafted)==1 else 'off'}"
    )

    fold_metrics: List[Dict[str, float]] = []
    overall_subject_ids: List[str] = []
    overall_question_digits: List[int] = []
    overall_chosen_digits: List[int] = []
    overall_seg_y: List[int] = []
    overall_seg_score: List[float] = []

    for fold in range(1, int(args.folds) + 1):
        train_ids, test_ids = build_fold_subject_ids(args.split_root, fold)
        train_ids = [sid for sid in train_ids if sid in sample_map]
        test_ids = [sid for sid in test_ids if sid in sample_map]
        if len(train_ids) == 0 or len(test_ids) == 0:
            print(f"fold {fold}: skipped (train={len(train_ids)}, test={len(test_ids)})")
            continue

        if args.select_on == "val":
            train_ids_use, val_ids = split_train_val_subjects(train_ids, args.val_ratio, seed=cfg.seed + fold)
            if len(val_ids) == 0:
                train_ids_use = train_ids
                val_ids = test_ids
            select_ids = val_ids
        else:
            train_ids_use = train_ids
            select_ids = test_ids

        Xtr, ytr, mtr, Ptr, Htr = _build_split_arrays(sample_map, train_ids_use)
        Xte, yte, mte, Pte, Hte = _build_split_arrays(sample_map, test_ids)
        Xsel, ysel, msel, Psel, Hsel = _build_split_arrays(sample_map, select_ids)

        if Xtr.shape[0] == 0 or Xte.shape[0] == 0 or Xsel.shape[0] == 0:
            print(f"fold {fold}: skipped (empty arrays)")
            continue

        model = Time2GraphPlusForGSR(cfg)
        model.fit_shapelets(Xtr)

        ftr, atr = model.build_graph_inputs(Xtr)
        fte, ate = model.build_graph_inputs(Xte)
        fsel, asel = model.build_graph_inputs(Xsel)

        if int(cfg.use_handcrafted) == 1:
            mu3 = np.mean(Htr, axis=0).astype(np.float32)
            sd3 = np.std(Htr, axis=0).astype(np.float32)
            model.set_handcrafted_norm(mu3, sd3)

        tr_ds = TensorDataset(
            torch.from_numpy(ftr.astype(np.float32)),
            torch.from_numpy(atr.astype(np.float32)),
            torch.from_numpy(Ptr.astype(np.float32)),
            torch.from_numpy(Htr.astype(np.float32)),
            torch.from_numpy(ytr.astype(np.int64)),
        )
        tr_ld = DataLoader(tr_ds, batch_size=cfg.batch_size, shuffle=True, drop_last=False)

        model = model.to(device)
        opt = torch.optim.Adam(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
        cls_weight = torch.tensor([1.0, float(cfg.pos_weight)], dtype=torch.float32, device=device)
        loss_fn = nn.CrossEntropyLoss(weight=cls_weight)

        best_key = -1e18
        best_ckpt = None
        best_epoch = 0

        for ep in range(1, int(cfg.epochs) + 1):
            model.train()
            pbar = tqdm(tr_ld, desc=f"fold {fold} ep {ep}/{cfg.epochs}", leave=False)
            for feat, adj, pp, hh, yy in pbar:
                feat = feat.to(device).float()
                adj = adj.to(device).float()
                pp = pp.to(device).float()
                hh = hh.to(device).float()
                yy = yy.to(device).long()
                logits = model(feat, adj, pp, hh)
                loss = loss_fn(logits, yy)
                opt.zero_grad(set_to_none=True)
                loss.backward()
                opt.step()
                pbar.set_postfix(loss=float(loss.item()))

            ys, ss = _run_eval(model, fsel, asel, Psel, Hsel, ysel, cfg.batch_size, device)
            seg_m = segment_metrics(ys, ss, thr=0.5)
            topk_m = subject_topk_metrics(
                subject_ids=msel["subject_id"],
                question_digits=np.asarray(msel["question_digit"], dtype=np.int64),
                chosen_digits=np.asarray(msel["chosen_digit"], dtype=np.int64),
                score_pos=ss,
                agg_mode=args.agg_mode,
            )
            key = float(topk_m["top1"] if args.select_metric == "top1" else seg_m["f1"])
            if key > best_key:
                best_key = key
                best_epoch = ep
                best_ckpt = model.to_ckpt()
            print(
                f"fold {fold} ep {ep}: select_{args.select_metric}={key:.4f} "
                f"(top1={topk_m['top1']:.4f}, f1={seg_m['f1']:.4f})"
            )

        if best_ckpt is None:
            print(f"fold {fold}: no checkpoint")
            continue

        fold_dir = out_dir / f"fold_{fold}"
        ensure_dir(str(fold_dir))
        ckpt_path = fold_dir / "best_ckpt.pt"
        torch.save(best_ckpt, ckpt_path)

        model_best = Time2GraphPlusForGSR.from_ckpt(best_ckpt).to(device)
        yt, st = _run_eval(model_best, fte, ate, Pte, Hte, yte, cfg.batch_size, device)
        seg_test = segment_metrics(yt, st, thr=0.5)
        topk_test = subject_topk_metrics(
            subject_ids=mte["subject_id"],
            question_digits=np.asarray(mte["question_digit"], dtype=np.int64),
            chosen_digits=np.asarray(mte["chosen_digit"], dtype=np.int64),
            score_pos=st,
            agg_mode=args.agg_mode,
        )

        _save_segment_predictions(fold_dir / "test_segment_scores.csv", fold, mte, yt, st)

        fold_row = {
            "fold": float(fold),
            "best_epoch": float(best_epoch),
            "n_subject": float(topk_test["n_subject"]),
            "top1": float(topk_test["top1"]),
            "top2": float(topk_test["top2"]),
            "top3": float(topk_test["top3"]),
            "seg_f1": float(seg_test["f1"]),
            "seg_auc": float(seg_test["auc"]),
        }
        fold_metrics.append(fold_row)
        print(
            f"fold {fold}: top1={topk_test['top1']*100:.2f}% "
            f"top2={topk_test['top2']*100:.2f}% top3={topk_test['top3']*100:.2f}% "
            f"(best_epoch={best_epoch})"
        )

        overall_subject_ids.extend([str(x) for x in mte["subject_id"]])
        overall_question_digits.extend(np.asarray(mte["question_digit"], dtype=np.int64).tolist())
        overall_chosen_digits.extend(np.asarray(mte["chosen_digit"], dtype=np.int64).tolist())
        overall_seg_y.extend(yt.astype(np.int64).tolist())
        overall_seg_score.extend(st.astype(np.float32).tolist())

    if len(fold_metrics) == 0:
        raise RuntimeError("No valid fold finished.")

    mean_top1 = float(np.mean([x["top1"] for x in fold_metrics]))
    mean_top2 = float(np.mean([x["top2"] for x in fold_metrics]))
    mean_top3 = float(np.mean([x["top3"] for x in fold_metrics]))

    overall_topk = subject_topk_metrics(
        subject_ids=overall_subject_ids,
        question_digits=np.asarray(overall_question_digits, dtype=np.int64),
        chosen_digits=np.asarray(overall_chosen_digits, dtype=np.int64),
        score_pos=np.asarray(overall_seg_score, dtype=np.float32),
        agg_mode=args.agg_mode,
    )
    overall_seg = segment_metrics(
        np.asarray(overall_seg_y, dtype=np.int64),
        np.asarray(overall_seg_score, dtype=np.float32),
        thr=0.5,
    )

    summary = {
        "config": cfg.__dict__,
        "select_on": args.select_on,
        "select_metric": args.select_metric,
        "agg_mode": args.agg_mode,
        "fold_metrics": fold_metrics,
        "mean_fold_top1": mean_top1,
        "mean_fold_top2": mean_top2,
        "mean_fold_top3": mean_top3,
        "overall_top1": float(overall_topk["top1"]),
        "overall_top2": float(overall_topk["top2"]),
        "overall_top3": float(overall_topk["top3"]),
        "overall_seg_f1": float(overall_seg["f1"]),
        "overall_seg_auc": float(overall_seg["auc"]),
    }

    with (out_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print("Per-fold metrics:")
    for r in fold_metrics:
        print(
            f"fold {int(r['fold'])}: n={int(r['n_subject'])} "
            f"top1={r['top1']*100:.2f}% top2={r['top2']*100:.2f}% top3={r['top3']*100:.2f}%"
        )
    print(
        f"Mean-fold: top1={mean_top1*100:.2f}% top2={mean_top2*100:.2f}% top3={mean_top3*100:.2f}%"
    )
    print(
        f"Overall: top1={overall_topk['top1']*100:.2f}% "
        f"top2={overall_topk['top2']*100:.2f}% top3={overall_topk['top3']*100:.2f}%"
    )
    print(f"Saved: {out_dir}")


if __name__ == "__main__":
    main()
