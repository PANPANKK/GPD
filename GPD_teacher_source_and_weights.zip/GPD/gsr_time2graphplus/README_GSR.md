# Time2GraphPlus-Style For GSR Guess-Number

This project adapts a Time2GraphPlus-style pipeline to your current dataset layout:

- Data root: `./data/<subject_id>/dataset/<session>/Event_003..022.csv` + `label.csv`
- Split root: `./data_split/5fold/fold_k/{train_ids.txt,test_ids.txt}`
- Fixed event preprocessing: lowpass 2Hz + resample 32Hz + fixed length 14s (`448` samples)

## Install

```bash
pip install -r gsr_time2graphplus/requirements.txt
```

## Train (5-fold)

Default is fold-wise training with test-set selection per epoch (`--select_on test`):

```bash
python gsr_time2graphplus/train_gsr.py \
  --data_root ./data \
  --split_root ./data_split/5fold \
  --out_dir ./results/time2graphplus_gsr_cv5 \
  --event_sec 14 \
  --target_fs 32 \
  --num_segment 14 \
  --seg_length 32 \
  --K 48 \
  --epochs 40 \
  --batch_size 64 \
  --device cuda
```

No personality:

```bash
python gsr_time2graphplus/train_gsr.py \
  --data_root ./data \
  --split_root ./data_split/5fold \
  --out_dir ./results/time2graphplus_gsr_cv5_no_p \
  --event_sec 14 \
  --target_fs 32 \
  --num_segment 14 \
  --seg_length 32 \
  --norm_mode subject \
  --use_personality 0 \
  --epochs 40 \
  --batch_size 64 \
  --device cuda
```

Big5 interaction:

```bash
python gsr_time2graphplus/train_gsr.py \
  --data_root ./data \
  --split_root ./data_split/5fold \
  --out_dir ./results/time2graphplus_gsr_cv5_big5_interaction \
  --event_sec 14 \
  --target_fs 32 \
  --num_segment 14 \
  --seg_length 32 \
  --norm_mode subject \
  --use_personality 1 \
  --personality_fusion interaction \
  --personality_scale 0.2 \
  --personality_hidden 16 \
  --epochs 40 \
  --batch_size 64 \
  --device cuda
```

## Inference

Use one fold checkpoint:

```bash
python gsr_time2graphplus/infer_gsr.py \
  --ckpt ./results/time2graphplus_gsr_cv5/fold_1/best_ckpt.pt \
  --data_root ./data \
  --split_root ./data_split/5fold \
  --fold 1 \
  --out_csv ./results/time2graphplus_gsr_cv5/fold_1_test_pred.csv
```

## Outputs

- `summary.json`: fold metrics + mean/overall top1/top2/top3
- `fold_k/best_ckpt.pt`: best checkpoint for fold `k`
- `fold_k/test_segment_scores.csv`: segment-level scores on fold test set
