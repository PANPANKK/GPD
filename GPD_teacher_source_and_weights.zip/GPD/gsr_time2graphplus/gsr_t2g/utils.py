import os
import random
from typing import Any

import numpy as np
import torch


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def pad_or_trunc_1d(x: np.ndarray, target_len: int) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32).reshape(-1)
    n = int(x.shape[0])
    if n == target_len:
        return x.astype(np.float32)
    if n > target_len:
        start = (n - target_len) // 2
        return x[start : start + target_len].astype(np.float32)
    pad_len = int(target_len - n)
    pad_val = float(x[-1]) if n > 0 else 0.0
    pad = np.full((pad_len,), pad_val, dtype=np.float32)
    return np.concatenate([x, pad], axis=0).astype(np.float32)


def z_norm(x: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    mu = float(np.mean(x))
    sd = float(np.std(x))
    return ((x - mu) / (sd + eps)).astype(np.float32)


def to_device(device: str) -> torch.device:
    if device == "cuda":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device == "cpu":
        return torch.device("cpu")
    return torch.device(device)


def as_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)
