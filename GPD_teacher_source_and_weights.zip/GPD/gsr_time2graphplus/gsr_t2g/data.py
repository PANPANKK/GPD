import csv
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy import signal as sp_signal

from .config import GSRTime2GraphConfig
from .personality import load_big5_vector
from .utils import pad_or_trunc_1d, z_norm


QUESTION_NUMBERS = [4, 8, 3, 1, 6, 9, 2, 5, 7, 10, 7, 2, 9, 3, 5, 1, 8, 10, 6, 4]
TARGET_QIDS = list(range(3, 23))


@dataclass
class SegmentRecord:
    subject_id: str
    seg_idx: int
    question_digit: int
    chosen_digit: int
    y: int


@dataclass
class SubjectSample:
    subject_id: str
    segments: np.ndarray  # (20, L)
    question_digits: np.ndarray  # (20,)
    chosen_digit: int
    big5: np.ndarray  # (5,)
    handcrafted3: np.ndarray  # (20, 3) -> [amp, auc, slope]


def digit_from_qid(qid: int) -> Optional[int]:
    if 3 <= qid <= 22:
        return int(QUESTION_NUMBERS[qid - 3])
    return None


def _norm_col_name(s: str) -> str:
    return " ".join(str(s).strip().split()).lower()


def pick_gsr_column(cols: List[str]) -> Optional[int]:
    priority = ["GSR Conductance_CAL", "GSR Conductance", "GSR_CAL", "GSR"]
    lower_map = {_norm_col_name(c): i for i, c in enumerate(cols)}
    for p in priority:
        k = _norm_col_name(p)
        if k in lower_map:
            return int(lower_map[k])
    for i, c in enumerate(cols):
        cl = _norm_col_name(c)
        if "gsr" in cl and "cal" in cl:
            return int(i)
    for i, c in enumerate(cols):
        if "gsr" in _norm_col_name(c):
            return int(i)
    return None


def locate_dataset_dir(data_root: Path, sid: str) -> Optional[Path]:
    sid_dir = data_root / sid
    if not sid_dir.exists() or not sid_dir.is_dir():
        return None
    if (sid_dir / "label.csv").exists():
        return sid_dir

    ds_root = sid_dir / "dataset"
    ds_dirs = [p for p in ds_root.iterdir() if p.is_dir()] if ds_root.exists() else []
    if len(ds_dirs) == 1:
        return ds_dirs[0]
    if len(ds_dirs) > 1:
        cands = [p for p in ds_dirs if (p / "label.csv").exists()]
        if len(cands) > 0:
            return sorted(cands)[0]
    return None


def hidden_number_from_label_csv(label_csv: Path) -> Optional[int]:
    if not label_csv.exists():
        return None
    try:
        rows = list(csv.DictReader(label_csv.open("r", encoding="utf-8-sig", newline="")))
    except Exception:
        rows = []
    if not rows:
        return None

    key_map = {str(k).strip().lower(): k for k in rows[0].keys()}

    for cand in ["hidden_number", "digit", "target", "answer"]:
        kk = key_map.get(cand)
        if kk is None:
            continue
        try:
            v = int(float(str(rows[0].get(kk, "")).strip()))
            if 1 <= v <= 10:
                return int(v)
        except Exception:
            continue

    qk = key_map.get("question_id")
    lk = key_map.get("label")
    if qk is None or lk is None:
        return None

    labels: Dict[int, int] = {}
    for r in rows:
        try:
            qv = int(float(str(r.get(qk, "")).strip()))
            lv = int(float(str(r.get(lk, "")).strip()))
            labels[qv] = lv
        except Exception:
            continue
    lie_qids = [q for q in TARGET_QIDS if labels.get(q, 0) == 1]
    if len(lie_qids) != 2:
        return None
    d1 = digit_from_qid(lie_qids[0])
    d2 = digit_from_qid(lie_qids[1])
    if d1 is None or d2 is None or d1 != d2:
        return None
    return int(d1)


def load_gsr_signal_from_event_csv(csv_path: Path) -> Optional[np.ndarray]:
    try:
        with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))
    except Exception:
        return None
    if len(rows) < 2:
        return None

    if len(rows) >= 5:
        name_row = rows[1]
        cal_row = rows[2]
        cols: List[str] = []
        n_col = min(len(name_row), len(cal_row))
        for i in range(n_col):
            n1 = str(name_row[i]).strip()
            n2 = str(cal_row[i]).strip()
            if n1 == "":
                cols.append("")
            elif n2 != "":
                cols.append(f"{n1}_{n2}")
            else:
                cols.append(n1)
        gsr_idx = pick_gsr_column(cols)
        if gsr_idx is not None:
            vals: List[float] = []
            for r in rows[4:]:
                if gsr_idx >= len(r):
                    continue
                s = str(r[gsr_idx]).strip()
                if s == "":
                    continue
                try:
                    vals.append(float(s))
                except Exception:
                    continue
            if len(vals) > 0:
                sig = np.asarray(vals, dtype=np.float32)
                sig = sig[np.isfinite(sig)]
                if sig.size > 0:
                    return sig.astype(np.float32)

    header = [str(x).strip() for x in rows[0]]
    gsr_idx = pick_gsr_column(header)
    if gsr_idx is None:
        return None
    vals2: List[float] = []
    for r in rows[1:]:
        if gsr_idx >= len(r):
            continue
        s = str(r[gsr_idx]).strip()
        if s == "":
            continue
        try:
            vals2.append(float(s))
        except Exception:
            continue
    if len(vals2) == 0:
        return None
    sig2 = np.asarray(vals2, dtype=np.float32)
    sig2 = sig2[np.isfinite(sig2)]
    return sig2.astype(np.float32) if sig2.size > 0 else None


def lowpass_then_resample(x: np.ndarray, fs_in: float, fs_out: float, lowpass_hz: float = 2.0) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32).reshape(-1)
    if x.size < 3:
        return x.astype(np.float32)
    nyq = 0.5 * fs_in
    w = lowpass_hz / max(nyq, 1e-6)
    w = min(max(w, 1e-4), 0.999)
    b, a = sp_signal.butter(4, w, btype="low")
    xf = sp_signal.filtfilt(b, a, x).astype(np.float32)
    n_out = int(round(float(xf.size) * float(fs_out) / float(fs_in)))
    n_out = max(2, n_out)
    return sp_signal.resample(xf, n_out).astype(np.float32)


def _smooth_signal(sig: np.ndarray, fs: float, window_sec: float = 0.5) -> np.ndarray:
    if window_sec <= 0:
        return sig.astype(np.float32)
    n = int(max(1, round(float(window_sec) * float(fs))))
    if n <= 1:
        return sig.astype(np.float32)
    kernel = np.ones((n,), dtype=np.float32) / float(n)
    return np.convolve(sig.astype(np.float32), kernel, mode="same").astype(np.float32)


def _extract_rule3_feature(sig: np.ndarray, fs: float) -> np.ndarray:
    x = np.asarray(sig, dtype=np.float32).reshape(-1)
    if x.size == 0:
        return np.zeros((3,), dtype=np.float32)

    n_base = int(max(1, round(3.0 * float(fs))))
    n_base = min(n_base, x.size)
    baseline = float(np.median(x[:n_base]))

    xs = _smooth_signal(x, fs=float(fs), window_sec=0.5)
    n_search = int(min(xs.size, round(10.0 * float(fs))))
    n_search = max(1, n_search)
    search = xs[:n_search]
    peak_idx = int(np.argmax(search))
    peak_val = float(search[peak_idx])

    amp = float(peak_val - baseline)
    lat = float(peak_idx) / max(float(fs), 1e-6)
    slope = float(amp / max(lat, 1e-6))
    auc = float(np.sum(np.maximum(x - baseline, 0.0)) / max(float(fs), 1e-6))

    arr = np.asarray([amp, auc, slope], dtype=np.float32)
    arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
    return arr


def preprocess_subject_segments(subject_dataset_dir: Path, cfg: GSRTime2GraphConfig) -> Optional[Tuple[np.ndarray, np.ndarray]]:
    event_len = int(round(float(cfg.target_fs) * float(cfg.event_sec)))
    parts: List[np.ndarray] = []
    h3: List[np.ndarray] = []
    for qid in TARGET_QIDS:
        csv_path = subject_dataset_dir / f"Event_{qid:03d}.csv"
        raw = load_gsr_signal_from_event_csv(csv_path)
        if raw is None:
            return None
        x = lowpass_then_resample(raw, cfg.source_fs, cfg.target_fs, lowpass_hz=cfg.lowpass_hz)
        x = pad_or_trunc_1d(x, event_len)
        h3.append(_extract_rule3_feature(x, fs=float(cfg.target_fs)))
        parts.append(x.astype(np.float32))
    segs = np.stack(parts, axis=0).astype(np.float32)  # (20, L)
    hand3 = np.stack(h3, axis=0).astype(np.float32) if len(h3) > 0 else np.zeros((20, 3), dtype=np.float32)

    mode = str(cfg.norm_mode).lower().strip()
    if mode == "subject":
        flat = segs.reshape(-1)
        flat = z_norm(flat)
        segs = flat.reshape(segs.shape).astype(np.float32)
    elif mode == "clip":
        segs = np.stack([z_norm(segs[i]) for i in range(segs.shape[0])], axis=0).astype(np.float32)
    else:
        raise ValueError(f"Unknown norm_mode: {cfg.norm_mode}")
    return segs, hand3


def subject_cache_file(cache_dir: Path, sid: str, cfg: GSRTime2GraphConfig) -> Path:
    tag = (
        f"s{cfg.source_fs:.1f}_lp{cfg.lowpass_hz:.2f}_t{cfg.target_fs:.1f}_"
        f"sec{cfg.event_sec:.1f}_{str(cfg.norm_mode).lower()}_"
        f"p{int(bool(cfg.use_personality))}_h{int(bool(getattr(cfg, 'use_handcrafted', 0)))}"
    ).replace(".", "p")
    return cache_dir / f"{sid}_{tag}.npz"


def load_subject_sample(
    data_root: Path,
    sid: str,
    cfg: GSRTime2GraphConfig,
    cache_dir: Optional[Path] = None,
) -> Optional[SubjectSample]:
    ds_dir = locate_dataset_dir(data_root, sid)
    if ds_dir is None:
        return None
    chosen = hidden_number_from_label_csv(ds_dir / "label.csv")
    if chosen is None:
        return None

    subject_dir = data_root / sid
    qdigits = np.asarray(QUESTION_NUMBERS, dtype=np.int64)
    big5 = load_big5_vector(subject_dir).astype(np.float32)
    hand3 = np.zeros((20, 3), dtype=np.float32)
    segs: Optional[np.ndarray] = None
    cpath: Optional[Path] = None
    if cache_dir is not None:
        cache_dir.mkdir(parents=True, exist_ok=True)
        cpath = subject_cache_file(cache_dir, sid, cfg)
        if cpath.exists():
            try:
                obj = np.load(cpath, allow_pickle=False)
                segs = obj["segments"].astype(np.float32)
                qdigits = obj["question_digits"].astype(np.int64)
                chosen_cache = int(obj["chosen_digit"])
                if 1 <= chosen_cache <= 10:
                    chosen = chosen_cache
                if "big5" in obj:
                    big5 = obj["big5"].astype(np.float32).reshape(-1)
                    if big5.shape[0] != 5:
                        big5 = np.zeros((5,), dtype=np.float32)
                if "handcrafted3" in obj:
                    hand3 = obj["handcrafted3"].astype(np.float32)
                    if hand3.ndim != 2 or hand3.shape[1] != 3:
                        hand3 = np.zeros((20, 3), dtype=np.float32)
            except Exception:
                segs = None

    if segs is None:
        obj = preprocess_subject_segments(ds_dir, cfg)
        if obj is None:
            return None
        segs, hand3 = obj
        if cpath is not None:
            try:
                np.savez_compressed(
                    cpath,
                    segments=segs.astype(np.float32),
                    question_digits=qdigits.astype(np.int64),
                    chosen_digit=np.asarray(chosen, dtype=np.int64),
                    big5=big5.astype(np.float32),
                    handcrafted3=hand3.astype(np.float32),
                )
            except Exception:
                pass
    else:
        if hand3.shape[0] != segs.shape[0]:
            hand3 = np.zeros((segs.shape[0], 3), dtype=np.float32)

    return SubjectSample(
        subject_id=str(sid),
        segments=segs.astype(np.float32),
        question_digits=qdigits.astype(np.int64),
        chosen_digit=int(chosen),
        big5=big5.astype(np.float32),
        handcrafted3=hand3.astype(np.float32),
    )


def scan_subjects(data_root: str) -> List[str]:
    root = Path(data_root)
    out: List[str] = []
    for p in sorted(root.iterdir()):
        if p.is_dir():
            out.append(p.name)
    return out


def read_id_list(path: Path) -> List[str]:
    if not path.exists():
        return []
    return [x.strip() for x in path.read_text(encoding="utf-8").splitlines() if x.strip()]


def build_fold_subject_ids(split_root: str, fold_idx: int) -> Tuple[List[str], List[str]]:
    sp = Path(split_root)
    tr = read_id_list(sp / f"fold_{fold_idx}" / "train_ids.txt")
    te = read_id_list(sp / f"fold_{fold_idx}" / "test_ids.txt")
    return tr, te


def collect_subject_ids_from_split(split_root: str, folds: int = 5) -> List[str]:
    ids: List[str] = []
    for k in range(1, int(folds) + 1):
        tr, te = build_fold_subject_ids(split_root, k)
        ids.extend(tr)
        ids.extend(te)
    seen = set()
    uniq: List[str] = []
    for sid in ids:
        if sid in seen:
            continue
        seen.add(sid)
        uniq.append(sid)
    return uniq


def load_subject_samples(
    data_root: str,
    subject_ids: List[str],
    cfg: GSRTime2GraphConfig,
    cache_dir: Optional[str] = None,
    num_workers: int = 1,
) -> Dict[str, SubjectSample]:
    root = Path(data_root)
    cdir = Path(cache_dir) if cache_dir else None
    sids = sorted(set(subject_ids))
    out: Dict[str, SubjectSample] = {}

    def _one(sid: str) -> Tuple[str, Optional[SubjectSample]]:
        return sid, load_subject_sample(root, sid, cfg, cdir)

    workers = int(max(1, num_workers))
    if workers <= 1:
        for sid in sids:
            sid_k, rec = _one(sid)
            if rec is not None:
                out[sid_k] = rec
        return out

    with ThreadPoolExecutor(max_workers=workers) as ex:
        for sid_k, rec in ex.map(_one, sids):
            if rec is not None:
                out[sid_k] = rec
    return out


def split_train_val_subjects(train_ids: List[str], val_ratio: float, seed: int) -> Tuple[List[str], List[str]]:
    ids = np.asarray(train_ids, dtype=object)
    if ids.size <= 3 or float(val_ratio) <= 0.0:
        return list(train_ids), []
    rng = np.random.default_rng(int(seed))
    idx = np.arange(ids.size)
    rng.shuffle(idx)
    n_val = int(round(ids.size * float(val_ratio)))
    n_val = max(1, min(n_val, ids.size - 1))
    val_idx = idx[:n_val]
    tr_idx = idx[n_val:]
    tr = [str(ids[i]) for i in tr_idx.tolist()]
    va = [str(ids[i]) for i in val_idx.tolist()]
    return tr, va


def build_segment_table(samples: List[SubjectSample]) -> Tuple[List[SegmentRecord], np.ndarray, np.ndarray, np.ndarray]:
    rows: List[SegmentRecord] = []
    xs: List[np.ndarray] = []
    ps: List[np.ndarray] = []
    hs: List[np.ndarray] = []
    for rec in samples:
        segs = np.asarray(rec.segments, dtype=np.float32)
        assert segs.ndim == 2 and segs.shape[0] == 20, f"{rec.subject_id}: expected segments shape (20,L), got {segs.shape}"
        assert rec.question_digits.shape[0] == 20
        p5 = np.asarray(rec.big5, dtype=np.float32).reshape(-1)
        if p5.shape[0] != 5:
            p5 = np.zeros((5,), dtype=np.float32)
        h3 = np.asarray(rec.handcrafted3, dtype=np.float32)
        if h3.ndim != 2 or h3.shape[0] != 20 or h3.shape[1] != 3:
            h3 = np.zeros((20, 3), dtype=np.float32)
        for i in range(20):
            q = int(rec.question_digits[i])
            c = int(rec.chosen_digit)
            y = int(q == c)
            rows.append(
                SegmentRecord(
                    subject_id=str(rec.subject_id),
                    seg_idx=int(i),
                    question_digit=int(q),
                    chosen_digit=int(c),
                    y=int(y),
                )
            )
            xs.append(segs[i].reshape(-1))
            ps.append(p5.copy())
            hs.append(h3[i].reshape(-1))
    X_raw = np.stack(xs, axis=0).astype(np.float32) if len(xs) > 0 else np.zeros((0, 0), dtype=np.float32)
    P_raw = np.stack(ps, axis=0).astype(np.float32) if len(ps) > 0 else np.zeros((0, 5), dtype=np.float32)
    H_raw = np.stack(hs, axis=0).astype(np.float32) if len(hs) > 0 else np.zeros((0, 3), dtype=np.float32)
    return rows, X_raw, P_raw, H_raw


def records_to_arrays(
    records: List[SegmentRecord], X_raw: np.ndarray, P_raw: np.ndarray, H_raw: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, Dict[str, object], np.ndarray, np.ndarray]:
    if X_raw.ndim != 2:
        raise ValueError(f"X_raw must be (N,L), got {X_raw.shape}")
    X = X_raw[..., None].astype(np.float32)  # (N,L,1)
    y = np.asarray([r.y for r in records], dtype=np.int64)
    P = np.asarray(P_raw, dtype=np.float32)
    if P.ndim != 2 or P.shape[0] != X.shape[0]:
        raise ValueError(f"P_raw must be (N,5), got {P.shape}, N={X.shape[0]}")
    if P.shape[1] != 5:
        raise ValueError(f"P_raw dim mismatch, expected 5, got {P.shape[1]}")
    H = np.asarray(H_raw, dtype=np.float32)
    if H.ndim != 2 or H.shape[0] != X.shape[0]:
        raise ValueError(f"H_raw must be (N,3), got {H.shape}, N={X.shape[0]}")
    if H.shape[1] != 3:
        raise ValueError(f"H_raw dim mismatch, expected 3, got {H.shape[1]}")
    meta = {
        "subject_id": [r.subject_id for r in records],
        "seg_idx": np.asarray([r.seg_idx for r in records], dtype=np.int64),
        "question_digit": np.asarray([r.question_digit for r in records], dtype=np.int64),
        "chosen_digit": np.asarray([r.chosen_digit for r in records], dtype=np.int64),
    }
    return X, y, meta, P.astype(np.float32), H.astype(np.float32)
