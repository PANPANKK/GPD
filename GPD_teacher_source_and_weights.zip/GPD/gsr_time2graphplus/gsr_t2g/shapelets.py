from typing import Optional

import numpy as np
from sklearn.cluster import MiniBatchKMeans


class ShapeletKMeans:
    def __init__(
        self,
        K: int,
        num_segment: int,
        seg_length: int,
        batch_size: int = 2048,
        max_iter: int = 200,
    ):
        self.K = int(K)
        self.num_segment = int(num_segment)
        self.seg_length = int(seg_length)
        self.batch_size = int(batch_size)
        self.max_iter = int(max_iter)
        self.centers_: Optional[np.ndarray] = None

    def fit(self, X: np.ndarray) -> "ShapeletKMeans":
        X = np.asarray(X, dtype=np.float32)
        assert X.ndim == 3 and X.shape[-1] == 1
        n, L, _ = X.shape
        exp_len = self.num_segment * self.seg_length
        assert L == exp_len, f"input length mismatch: got {L}, expect {exp_len}"
        segs = X[..., 0].reshape(n, self.num_segment, self.seg_length)
        pool = segs.reshape(n * self.num_segment, self.seg_length)

        km = MiniBatchKMeans(
            n_clusters=self.K,
            batch_size=self.batch_size,
            max_iter=self.max_iter,
            n_init="auto",
            random_state=0,
        )
        km.fit(pool)
        self.centers_ = km.cluster_centers_.astype(np.float32)
        return self

    def transform_dist(self, X: np.ndarray) -> np.ndarray:
        if self.centers_ is None:
            raise RuntimeError("call fit() first")
        X = np.asarray(X, dtype=np.float32)
        n, L, _ = X.shape
        exp_len = self.num_segment * self.seg_length
        assert L == exp_len, f"input length mismatch: got {L}, expect {exp_len}"
        segs = X[..., 0].reshape(n, self.num_segment, self.seg_length)  # (N,m,sl)
        a = segs[:, :, None, :]  # (N,m,1,sl)
        b = self.centers_[None, None, :, :]  # (1,1,K,sl)
        dist = np.sqrt(np.sum((a - b) ** 2, axis=-1)).astype(np.float32)  # (N,m,K)
        return dist

    def export(self) -> np.ndarray:
        if self.centers_ is None:
            raise RuntimeError("shapelets not fitted")
        return self.centers_.copy()

    def load(self, centers: np.ndarray) -> "ShapeletKMeans":
        c = np.asarray(centers, dtype=np.float32)
        if c.ndim != 2 or c.shape[0] != self.K or c.shape[1] != self.seg_length:
            raise ValueError(f"shapelet centers shape mismatch: got {c.shape}, expect ({self.K}, {self.seg_length})")
        self.centers_ = c.copy()
        return self
