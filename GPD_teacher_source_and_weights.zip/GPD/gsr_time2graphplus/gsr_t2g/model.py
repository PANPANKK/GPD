from dataclasses import asdict
from typing import Dict, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import GSRTime2GraphConfig
from .gat import DenseMultiHeadGAT
from .graph import build_adj_from_dist, dist_to_node_features
from .shapelets import ShapeletKMeans


class Time2GraphPlusForGSR(nn.Module):
    def __init__(self, cfg: GSRTime2GraphConfig):
        super().__init__()
        self.cfg = cfg
        self.shapelets = ShapeletKMeans(
            K=cfg.K,
            num_segment=cfg.num_segment,
            seg_length=cfg.seg_length,
            batch_size=cfg.kmeans_batch_size,
            max_iter=cfg.kmeans_max_iter,
        )

        fin = cfg.num_segment
        hidden = cfg.gat_hidden
        heads = cfg.gat_heads

        self.gat1 = DenseMultiHeadGAT(
            fin=fin,
            fout=hidden,
            n_heads=heads,
            dropout=cfg.gat_dropout,
            alpha=cfg.gat_alpha,
            concat=True,
        )

        fin2 = hidden * heads
        if int(cfg.num_layers) >= 2:
            self.gat2 = DenseMultiHeadGAT(
                fin=fin2,
                fout=hidden,
                n_heads=1,
                dropout=cfg.gat_dropout,
                alpha=cfg.gat_alpha,
                concat=False,
            )
            out_dim = hidden
        else:
            self.gat2 = None
            out_dim = fin2

        self.out_dim = int(out_dim)
        self.dropout = nn.Dropout(cfg.gat_dropout)

        self.use_personality = bool(int(getattr(cfg, "use_personality", 0)))
        self.personality_scale = float(getattr(cfg, "personality_scale", 0.2))
        self.personality_fusion = str(getattr(cfg, "personality_fusion", "interaction")).lower().strip()
        self.personality_hidden = int(getattr(cfg, "personality_hidden", 16))
        self.use_handcrafted = bool(int(getattr(cfg, "use_handcrafted", 0)))
        self.handcrafted_scale = float(getattr(cfg, "handcrafted_scale", 1.0))
        self.handcrafted_fusion = str(getattr(cfg, "handcrafted_fusion", "interaction")).lower().strip()
        self.handcrafted_hidden = int(getattr(cfg, "handcrafted_hidden", 16))

        cls_in = self.out_dim
        if self.use_personality:
            self.p_proj = nn.Sequential(
                nn.Linear(5, self.personality_hidden),
                nn.ReLU(),
                nn.Dropout(cfg.gat_dropout),
            )
            if self.personality_fusion == "interaction":
                self.p_to_graph = nn.Linear(self.personality_hidden, self.out_dim)
                cls_in += self.out_dim
            cls_in += self.personality_hidden

        if self.use_handcrafted:
            self.h_proj = nn.Sequential(
                nn.Linear(3, self.handcrafted_hidden),
                nn.ReLU(),
                nn.Dropout(cfg.gat_dropout),
            )
            if self.handcrafted_fusion == "interaction":
                self.h_to_graph = nn.Linear(self.handcrafted_hidden, self.out_dim)
                cls_in += self.out_dim
            cls_in += self.handcrafted_hidden
            self.register_buffer("hand_mu", torch.zeros((3,), dtype=torch.float32))
            self.register_buffer("hand_sd", torch.ones((3,), dtype=torch.float32))

        self.cls = nn.Linear(int(cls_in), 2)

    @torch.no_grad()
    def set_handcrafted_norm(self, mean3: np.ndarray, std3: np.ndarray) -> None:
        if not self.use_handcrafted:
            return
        mu = np.asarray(mean3, dtype=np.float32).reshape(-1)
        sd = np.asarray(std3, dtype=np.float32).reshape(-1)
        if mu.shape[0] != 3 or sd.shape[0] != 3:
            raise ValueError(f"handcrafted norm expects 3 dims, got mu={mu.shape}, sd={sd.shape}")
        sd = np.where(np.abs(sd) < 1e-6, 1.0, sd).astype(np.float32)
        self.hand_mu.copy_(torch.from_numpy(mu))
        self.hand_sd.copy_(torch.from_numpy(sd))

    def fit_shapelets(self, X_train: np.ndarray) -> None:
        self.shapelets.fit(X_train)

    def build_graph_inputs(self, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        dist = self.shapelets.transform_dist(X)  # (N,m,K)
        feats = dist_to_node_features(dist)  # (N,K,m)
        adjs = []
        for i in range(dist.shape[0]):
            adj, _ = build_adj_from_dist(
                dist[i],
                percentile=float(self.cfg.percentile),
                self_loop=bool(self.cfg.use_self_loop),
            )
            adjs.append(adj.astype(np.float32))
        adjs_arr = np.stack(adjs, axis=0).astype(np.float32) if len(adjs) > 0 else np.zeros((0, self.cfg.K, self.cfg.K), dtype=np.float32)
        return feats.astype(np.float32), adjs_arr

    def forward(
        self,
        feats: torch.Tensor,
        adjs: torch.Tensor,
        personality: torch.Tensor = None,
        handcrafted: torch.Tensor = None,
    ) -> torch.Tensor:
        x = self.gat1(feats, adjs)
        x = F.elu(x)
        x = self.dropout(x)
        if self.gat2 is not None:
            x = self.gat2(x, adjs)
            x = F.elu(x)
            x = self.dropout(x)
        g = x.mean(dim=1)  # (B, out_dim)

        parts = [g]

        if self.use_personality:
            if personality is None:
                p = torch.zeros((g.size(0), 5), dtype=g.dtype, device=g.device)
            else:
                p = personality.to(g.device).float()
                if p.ndim == 1:
                    p = p.unsqueeze(0)
            if p.shape[-1] != 5:
                raise ValueError(f"personality dim mismatch, expected 5 got {p.shape[-1]}")
            p = p * float(self.personality_scale)
            p_emb = self.p_proj(p)  # (B, p_hidden)
            if self.personality_fusion == "interaction":
                gate = torch.tanh(self.p_to_graph(p_emb))  # (B, out_dim)
                inter = g * gate
                parts.append(inter)
            parts.append(p_emb)

        if self.use_handcrafted:
            if handcrafted is None:
                h3 = torch.zeros((g.size(0), 3), dtype=g.dtype, device=g.device)
            else:
                h3 = handcrafted.to(g.device).float()
                if h3.ndim == 1:
                    h3 = h3.unsqueeze(0)
            if h3.shape[-1] != 3:
                raise ValueError(f"handcrafted dim mismatch, expected 3 got {h3.shape[-1]}")
            mu = self.hand_mu.to(g.device).unsqueeze(0)
            sd = self.hand_sd.to(g.device).unsqueeze(0)
            h3 = (h3 - mu) / (sd + 1e-6)
            h3 = h3 * float(self.handcrafted_scale)
            h_emb = self.h_proj(h3)
            if self.handcrafted_fusion == "interaction":
                gate_h = torch.tanh(self.h_to_graph(h_emb))
                inter_h = g * gate_h
                parts.append(inter_h)
            parts.append(h_emb)

        z = torch.cat(parts, dim=-1) if len(parts) > 1 else parts[0]

        logits = self.cls(z)
        return logits

    def to_ckpt(self) -> Dict:
        centers = self.shapelets.export().copy()
        # Freeze parameters at current epoch.
        # state_dict() tensors may share storage with live model params; clone to avoid being
        # mutated by later optimizer steps when "best" checkpoint is kept in memory.
        state_frozen = {k: v.detach().cpu().clone() for k, v in self.state_dict().items()}
        return {
            "cfg": asdict(self.cfg),
            "shapelet_centers": centers,
            "state_dict": state_frozen,
        }

    @staticmethod
    def from_ckpt(ckpt: Dict) -> "Time2GraphPlusForGSR":
        cfg = GSRTime2GraphConfig(**ckpt["cfg"])
        model = Time2GraphPlusForGSR(cfg)
        model.shapelets.load(ckpt["shapelet_centers"])
        model.load_state_dict(ckpt["state_dict"], strict=True)
        return model
