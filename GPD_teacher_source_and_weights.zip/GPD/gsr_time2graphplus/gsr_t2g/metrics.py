from typing import Dict, List, Sequence, Tuple

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score


def segment_metrics(y_true: np.ndarray, score_pos: np.ndarray, thr: float = 0.5) -> Dict[str, float]:
    yt = np.asarray(y_true, dtype=np.int64).reshape(-1)
    sp = np.asarray(score_pos, dtype=np.float32).reshape(-1)
    yp = (sp >= float(thr)).astype(np.int64)

    out = {
        "acc": float(accuracy_score(yt, yp)),
        "prec": float(precision_score(yt, yp, zero_division=0)),
        "recall": float(recall_score(yt, yp, zero_division=0)),
        "f1": float(f1_score(yt, yp, zero_division=0)),
    }
    try:
        out["auc"] = float(roc_auc_score(yt, sp))
    except Exception:
        out["auc"] = float("nan")
    return out


def _aggregate_digit(scores: np.ndarray, agg_mode: str) -> float:
    x = np.asarray(scores, dtype=np.float32).reshape(-1)
    if x.size == 0:
        return -1e9
    m = str(agg_mode).lower().strip()
    if m == "sum":
        return float(np.sum(x))
    if m == "mean":
        return float(np.mean(x))
    if m == "max":
        return float(np.max(x))
    if m == "logsumexp":
        xmax = float(np.max(x))
        return float(xmax + np.log(np.sum(np.exp(x - xmax)) + 1e-12))
    raise ValueError(f"Unknown agg_mode: {agg_mode}")


def _rank_digits(question_digits: np.ndarray, score_pos: np.ndarray, agg_mode: str = "mean") -> Tuple[List[int], np.ndarray]:
    q = np.asarray(question_digits, dtype=np.int64).reshape(-1)
    s = np.asarray(score_pos, dtype=np.float32).reshape(-1)
    digit_scores = np.full((10,), -1e9, dtype=np.float32)
    for d in range(1, 11):
        idx = np.where(q == d)[0]
        if idx.size == 0:
            continue
        digit_scores[d - 1] = _aggregate_digit(s[idx], agg_mode=agg_mode)
    ranked = (np.argsort(digit_scores)[::-1] + 1).astype(int).tolist()
    return ranked, digit_scores


def subject_topk_metrics(
    subject_ids: Sequence[str],
    question_digits: np.ndarray,
    chosen_digits: np.ndarray,
    score_pos: np.ndarray,
    agg_mode: str = "mean",
) -> Dict[str, float]:
    sids = np.asarray(list(subject_ids), dtype=object)
    qd = np.asarray(question_digits, dtype=np.int64).reshape(-1)
    cd = np.asarray(chosen_digits, dtype=np.int64).reshape(-1)
    sp = np.asarray(score_pos, dtype=np.float32).reshape(-1)
    uniq = sorted(set(sids.tolist()))
    if len(uniq) == 0:
        return {"n_subject": 0.0, "top1": 0.0, "top2": 0.0, "top3": 0.0}

    hit1 = 0
    hit2 = 0
    hit3 = 0
    for sid in uniq:
        idx = np.where(sids == sid)[0]
        if idx.size == 0:
            continue
        ranked, _ = _rank_digits(qd[idx], sp[idx], agg_mode=agg_mode)
        true_d = int(cd[idx][0])
        if len(ranked) >= 1 and true_d == int(ranked[0]):
            hit1 += 1
        if true_d in ranked[:2]:
            hit2 += 1
        if true_d in ranked[:3]:
            hit3 += 1
    n = float(len(uniq))
    return {"n_subject": n, "top1": float(hit1 / n), "top2": float(hit2 / n), "top3": float(hit3 / n)}
