from dataclasses import dataclass


@dataclass
class GSRTime2GraphConfig:
    # Preprocess
    source_fs: float = 256.0
    target_fs: float = 32.0
    lowpass_hz: float = 2.0
    event_sec: float = 14.0
    norm_mode: str = "subject"  # subject | clip

    # Segment inside one event, ensure num_segment * seg_length == target_fs * event_sec
    num_segment: int = 14
    seg_length: int = 32

    # Shapelets
    K: int = 48
    kmeans_batch_size: int = 2048
    kmeans_max_iter: int = 200

    # Graph
    percentile: float = 85.0
    use_self_loop: bool = True

    # Dense GAT
    gat_hidden: int = 32
    gat_heads: int = 4
    gat_dropout: float = 0.2
    gat_alpha: float = 0.2
    num_layers: int = 2

    # Train
    seed: int = 42
    device: str = "cuda"
    lr: float = 1e-3
    weight_decay: float = 5e-4
    epochs: int = 40
    batch_size: int = 64
    pos_weight: float = 5.0

    # Personality (Big5)
    use_personality: int = 0
    personality_scale: float = 0.2
    personality_hidden: int = 16
    personality_fusion: str = "interaction"  # interaction | concat

    # Handcrafted rule features (amp / auc / slope)
    use_handcrafted: int = 0
    handcrafted_scale: float = 1.0
    handcrafted_hidden: int = 16
    handcrafted_fusion: str = "interaction"  # interaction | concat
