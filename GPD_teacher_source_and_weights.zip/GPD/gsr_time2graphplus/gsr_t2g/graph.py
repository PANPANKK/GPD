from typing import Tuple

import numpy as np


def _minmax_scale_1d(x: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    mn = float(np.min(x))
    mx = float(np.max(x))
    if mx - mn < eps:
        return np.zeros_like(x, dtype=np.float32)
    return ((x - mn) / (mx - mn + eps)).astype(np.float32)


def build_adj_from_dist(dist: np.ndarray, percentile: float = 85.0, self_loop: bool = True) -> Tuple[np.ndarray, float]:
    dist = np.asarray(dist, dtype=np.float32)
    m, K = dist.shape
    tmat = np.zeros((K, K), dtype=np.float32)
    for s in range(m - 1):
        src = 1.0 - _minmax_scale_1d(dist[s])
        dst = 1.0 - _minmax_scale_1d(dist[s + 1])
        tmat += src[:, None] * dst[None, :]
    thr = float(np.percentile(tmat, percentile))
    adj = (tmat >= thr).astype(np.float32)
    if bool(self_loop):
        np.fill_diagonal(adj, 1.0)
    return adj, thr


def dist_to_node_features(dist: np.ndarray) -> np.ndarray:
    # (N,m,K) -> (N,K,m)
    return np.transpose(np.asarray(dist, dtype=np.float32), (0, 2, 1)).astype(np.float32)
