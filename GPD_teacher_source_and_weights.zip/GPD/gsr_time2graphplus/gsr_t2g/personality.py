import csv
import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np


BFI2_DOMAINS: Dict[str, List[Tuple[int, bool]]] = {
    "E": [(1, False), (6, False), (11, True), (16, True), (21, False), (26, True), (31, True), (36, True), (41, False), (46, False), (51, True), (56, False)],
    "A": [(2, False), (7, False), (12, True), (17, True), (22, True), (27, False), (32, False), (37, True), (42, True), (47, True), (52, False), (57, False)],
    "C": [(3, True), (8, True), (13, False), (18, False), (23, True), (28, True), (33, False), (38, False), (43, False), (48, True), (53, False), (58, True)],
    "N": [(4, True), (9, True), (14, False), (19, False), (24, True), (29, True), (34, False), (39, False), (44, True), (49, True), (54, False), (59, False)],
    "O": [(5, True), (10, False), (15, False), (20, False), (25, True), (30, True), (35, False), (40, False), (45, True), (50, True), (55, True), (60, False)],
}
BFI2_DOMAIN_ORDER = ["O", "C", "E", "A", "N"]


def _safe_float(x, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)


def _to_len60(raw60: np.ndarray) -> np.ndarray:
    x = np.asarray(raw60, dtype=np.float32).reshape(-1)
    if x.size < 60:
        x = np.pad(x, (0, 60 - x.size), mode="constant")
    elif x.size > 60:
        x = x[:60]
    return np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)


def _reverse_score(v: float, lo: float = 1.0, hi: float = 5.0) -> float:
    return (lo + hi) - float(v)


def _score_items(x60: np.ndarray, items: List[Tuple[int, bool]], lo: float = 1.0, hi: float = 5.0) -> float:
    vals: List[float] = []
    for idx1, is_rev in items:
        v = float(x60[int(idx1) - 1])
        if is_rev:
            v = _reverse_score(v, lo=lo, hi=hi)
        vals.append(v)
    if len(vals) == 0:
        return 0.0
    return float(np.mean(vals))


def raw60_to_big5(raw60: np.ndarray) -> np.ndarray:
    x60 = _to_len60(raw60)
    dom_scores = {k: _score_items(x60, BFI2_DOMAINS[k]) for k in BFI2_DOMAINS.keys()}
    v5 = np.asarray([dom_scores[k] for k in BFI2_DOMAIN_ORDER], dtype=np.float32)
    return v5


def read_bfi_row60_csv(csv_path: Path) -> Optional[np.ndarray]:
    if not csv_path.exists():
        return None
    try:
        rows = list(csv.DictReader(csv_path.open("r", encoding="utf-8-sig", newline="")))
    except Exception:
        rows = []
    if not rows:
        return None
    row = rows[0]
    keys = sorted([k for k in row.keys() if str(k).strip().isdigit()], key=lambda z: int(z))
    if len(keys) == 0:
        return None
    vals = [_safe_float(row.get(k, 0.0), 0.0) for k in keys]
    return _to_len60(np.asarray(vals, dtype=np.float32))


def _parse_big5_from_row(row: Dict[str, str]) -> Optional[np.ndarray]:
    if not row:
        return None
    pref_keys = [k for k in row.keys() if str(k).lower().startswith("big5_")]
    if len(pref_keys) >= 5:
        pref_keys = sorted(pref_keys, key=lambda x: int(str(x).split("_")[-1]))
        vals = [_safe_float(row.get(k, 0.0), 0.0) for k in pref_keys[:5]]
        return np.asarray(vals, dtype=np.float32)
    num_keys = sorted([k for k in row.keys() if str(k).strip().isdigit()], key=lambda x: int(x))
    if len(num_keys) >= 5:
        vals = [_safe_float(row.get(k, 0.0), 0.0) for k in num_keys[:5]]
        return np.asarray(vals, dtype=np.float32)
    return None


def load_big5_vector(subject_dir: Path) -> np.ndarray:
    # 1) cache csv
    csv_path = subject_dir / "bfi_big5.csv"
    if csv_path.exists():
        try:
            rows = list(csv.DictReader(csv_path.open("r", encoding="utf-8-sig", newline="")))
        except Exception:
            rows = []
        if rows:
            arr = _parse_big5_from_row(rows[0])
            if arr is not None and arr.shape[0] == 5:
                return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)

    # 2) cache json
    json_path = subject_dir / "bfi_big5.json"
    if json_path.exists():
        try:
            obj = json.loads(json_path.read_text(encoding="utf-8"))
        except Exception:
            obj = None
        if isinstance(obj, dict):
            arr = _parse_big5_from_row({k: str(v) for k, v in obj.items()})
            if arr is not None and arr.shape[0] == 5:
                return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)
        if isinstance(obj, list) and len(obj) >= 5:
            arr = np.asarray([_safe_float(v, 0.0) for v in obj[:5]], dtype=np.float32)
            return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32)

    # 3) raw60
    raw60 = read_bfi_row60_csv(subject_dir / "bfi_row.csv")
    if raw60 is not None:
        return raw60_to_big5(raw60).astype(np.float32)

    return np.zeros((5,), dtype=np.float32)
