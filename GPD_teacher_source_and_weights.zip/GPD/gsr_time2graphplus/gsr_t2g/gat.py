from typing import List

import torch
import torch.nn as nn
import torch.nn.functional as F


class DenseGATLayer(nn.Module):
    def __init__(self, fin: int, fout: int, dropout: float, alpha: float):
        super().__init__()
        self.W = nn.Linear(fin, fout, bias=False)
        self.a = nn.Linear(2 * fout, 1, bias=False)
        self.dropout = float(dropout)
        self.leakyrelu = nn.LeakyReLU(alpha)

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        B, N, _ = x.shape
        h = self.W(x)  # (B,N,F)
        hi = h.unsqueeze(2).expand(B, N, N, h.size(-1))
        hj = h.unsqueeze(1).expand(B, N, N, h.size(-1))
        a_input = torch.cat([hi, hj], dim=-1)
        e = self.leakyrelu(self.a(a_input).squeeze(-1))  # (B,N,N)

        neg_inf = torch.tensor(-1e9, device=e.device, dtype=e.dtype)
        e = torch.where(adj > 0, e, neg_inf)

        attn = F.softmax(e, dim=-1)
        attn = F.dropout(attn, p=self.dropout, training=self.training)
        out = torch.bmm(attn, h)
        return out


class DenseMultiHeadGAT(nn.Module):
    def __init__(self, fin: int, fout: int, n_heads: int, dropout: float, alpha: float, concat: bool = True):
        super().__init__()
        self.concat = bool(concat)
        self.heads = nn.ModuleList(
            [DenseGATLayer(fin=fin, fout=fout, dropout=dropout, alpha=alpha) for _ in range(int(n_heads))]
        )

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        outs: List[torch.Tensor] = [h(x, adj) for h in self.heads]
        if self.concat:
            return torch.cat(outs, dim=-1)
        return torch.stack(outs, dim=0).mean(dim=0)
