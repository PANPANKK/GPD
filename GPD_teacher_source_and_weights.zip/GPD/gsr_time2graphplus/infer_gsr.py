import argparse
import csv
from pathlib import Path
from typing import List

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

from gsr_t2g.data import (
    build_fold_subject_ids,
    build_segment_table,
    collect_subject_ids_from_split,
    load_subject_samples,
    records_to_arrays,
)
from gsr_t2g.metrics import segment_metrics, subject_topk_metrics
from gsr_t2g.model import Time2GraphPlusForGSR
from gsr_t2g.utils import ensure_dir, to_device


def main() -> None:
    ap = argparse.ArgumentParser(description="Inference for Time2GraphPlus GSR model")
    ap.add_argument("--ckpt", type=str, required=True)
    ap.add_argument("--data_root", type=str, default="./data")
    ap.add_argument("--split_root", type=str, default="")
    ap.add_argument("--fold", type=int, default=0, help="if >0 and split_root set, infer only fold test IDs")
    ap.add_argument("--out_csv", type=str, required=True)
    ap.add_argument("--batch_size", type=int, default=128)
    ap.add_argument("--num_workers", type=int, default=4)
    ap.add_argument("--agg_mode", type=str, default="mean", choices=["sum", "mean", "logsumexp", "max"])
    args = ap.parse_args()

    ckpt = torch.load(args.ckpt, map_location="cpu")
    model = Time2GraphPlusForGSR.from_ckpt(ckpt)
    cfg = model.cfg
    device = to_device(cfg.device)
    model = model.to(device).eval()

    if str(args.split_root).strip() and int(args.fold) > 0:
        _, subject_ids = build_fold_subject_ids(args.split_root, int(args.fold))
    elif str(args.split_root).strip():
        subject_ids = collect_subject_ids_from_split(args.split_root, folds=5)
    else:
        from gsr_t2g.data import scan_subjects

        subject_ids = scan_subjects(args.data_root)

    samples = load_subject_samples(
        data_root=args.data_root,
        subject_ids=subject_ids,
        cfg=cfg,
        cache_dir="",
        num_workers=args.num_workers,
    )
    keep_ids = [sid for sid in subject_ids if sid in samples]
    recs, X_raw, P_raw, H_raw = build_segment_table([samples[sid] for sid in keep_ids])
    X, y, meta, P, H = records_to_arrays(recs, X_raw, P_raw, H_raw)

    feats, adjs = model.build_graph_inputs(X)
    ds = TensorDataset(
        torch.from_numpy(feats.astype(np.float32)),
        torch.from_numpy(adjs.astype(np.float32)),
        torch.from_numpy(P.astype(np.float32)),
        torch.from_numpy(H.astype(np.float32)),
        torch.from_numpy(y.astype(np.int64)),
    )
    ld = DataLoader(ds, batch_size=int(args.batch_size), shuffle=False)

    scores: List[np.ndarray] = []
    with torch.no_grad():
        for feat, adj, pp, hh, _ in ld:
            feat = feat.to(device).float()
            adj = adj.to(device).float()
            pp = pp.to(device).float()
            hh = hh.to(device).float()
            logits = model(feat, adj, pp, hh)
            ppos = torch.softmax(logits, dim=1)[:, 1]
            scores.append(ppos.cpu().numpy())
    score_pos = np.concatenate(scores, axis=0) if len(scores) > 0 else np.zeros((0,), dtype=np.float32)

    out_path = Path(args.out_csv)
    ensure_dir(str(out_path.parent))
    with out_path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["subject_id", "seg_idx", "question_digit", "chosen_digit", "y_true", "score_pos"])
        for i in range(len(meta["subject_id"])):
            w.writerow(
                [
                    str(meta["subject_id"][i]),
                    int(np.asarray(meta["seg_idx"], dtype=np.int64)[i]),
                    int(np.asarray(meta["question_digit"], dtype=np.int64)[i]),
                    int(np.asarray(meta["chosen_digit"], dtype=np.int64)[i]),
                    int(y[i]),
                    float(score_pos[i]),
                ]
            )

    seg_m = segment_metrics(y, score_pos, thr=0.5)
    topk_m = subject_topk_metrics(
        subject_ids=meta["subject_id"],
        question_digits=np.asarray(meta["question_digit"], dtype=np.int64),
        chosen_digits=np.asarray(meta["chosen_digit"], dtype=np.int64),
        score_pos=score_pos,
        agg_mode=args.agg_mode,
    )
    print(f"Saved CSV: {out_path}")
    print(f"Aggregation mode: {args.agg_mode}")
    print(
        f"TopK: top1={topk_m['top1']*100:.2f}% top2={topk_m['top2']*100:.2f}% top3={topk_m['top3']*100:.2f}%"
    )
    print(f"Segment: f1={seg_m['f1']:.4f} auc={seg_m['auc']:.4f}")


if __name__ == "__main__":
    main()
