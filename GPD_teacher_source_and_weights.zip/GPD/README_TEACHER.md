# GSR Teacher Model

This package provides the five trained Time2GraphPlus GSR teacher checkpoints and their matching implementation for GPD.

Merge the contents of this `GPD` folder into the existing repository root. Keep the five fold directories together; student fold i must load teacher fold i.

```text
gsr_time2graphplus/
  train_gsr.py
  infer_gsr.py
  requirements.txt
  gsr_t2g/
teacher_checkpoints/
  fold_1/best_ckpt.pt
  fold_2/best_ckpt.pt
  fold_3/best_ckpt.pt
  fold_4/best_ckpt.pt
  fold_5/best_ckpt.pt
  teacher_config.json
  SHA256SUMS
```

## Install and use

```bash
pip install -r gsr_time2graphplus/requirements.txt
export VIDEO_TEACHER_REPO_ROOT="$PWD/gsr_time2graphplus"
export VIDEO_TEACHER_CKPT_ROOT="$PWD/teacher_checkpoints"
export AUDIO_TEACHER_REPO_ROOT="$PWD/gsr_time2graphplus"
export AUDIO_TEACHER_CKPT_ROOT="$PWD/teacher_checkpoints"
```

The student experiment wrappers additionally need the corresponding data and split roots from the main README. Direct Python calls use `--teacher_repo_root ./gsr_time2graphplus --teacher_ckpt_root ./teacher_checkpoints --teacher_type time2graph`.

The frozen teacher uses GSR input and three GSR-derived handcrafted features (amplitude, area and slope), with no Big-Five input. Its classifier input/penultimate feature has dimension 80. GSR preprocessing is 2 Hz low-pass filtering, downsampling 256→32 Hz, and fixed 14-second segments (448 samples). Checkpoints contain the configuration, learned shapelet centers and model state, including handcrafted-feature normalization statistics.

`teacher_config.json` records the original teacher training settings. The teacher was trained for 80 epochs, batch size 64, learning rate 1e-3, weight decay 5e-4, seed 42. These are teacher settings, distinct from the 120-epoch student settings. To train this teacher configuration on the approved dataset and matching fold assignments:

```bash
python gsr_time2graphplus/train_gsr.py \
  --data_root /path/to/data --split_root /path/to/5fold \
  --out_dir /path/to/new_teacher_output \
  --source_fs 256 --target_fs 32 --lowpass_hz 2 --event_sec 14 \
  --norm_mode subject --num_segment 14 --seg_length 32 --K 48 --percentile 85 \
  --use_personality 0 --use_handcrafted 1 \
  --handcrafted_scale 1 --handcrafted_hidden 16 --handcrafted_fusion interaction \
  --epochs 80 --batch_size 64 --lr 1e-3 --weight_decay 5e-4 --pos_weight 5 \
  --seed 42 --device cuda --select_on test --select_metric top1 --agg_mode mean
```

All five checkpoints were loaded strictly and passed finite-output CPU inference. The current student adapter also passed a synthetic raw-GSR preprocessing and inference test, returning 20 question scores and 80-dimensional teacher features. Real-dataset performance was not rerun during packaging.

This package contains model checkpoints and code, not raw participant data, feature caches, or participant-level prediction files.

Dataset access applications: darcy981020@gmail.com
